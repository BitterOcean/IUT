----View Implementation 
CREATE VIEW vAdditionalContactInfo
AS 
SELECT CustomerID,FirstName,LastName,City,Address
FROM Customer  INNER JOIN Territory ON Customer.TerritoryID=Territory.TerritoryID
GO

CREATE VIEW vProductAndDescription
AS 
SELECT 
    ProductID 
    ,ProductName
	,CategoryName AS Category
    ,BrandName
	,Explanation AS Description
FROM Product INNER JOIN Category ON Product.CategoryID=Category.CategoryID
GO

CREATE VIEW vPhoneBook
AS 
SELECT FirstName,LastName,Phone,PostalCode
FROM Customer
GO

