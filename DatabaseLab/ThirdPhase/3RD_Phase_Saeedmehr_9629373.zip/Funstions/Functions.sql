
----Function Implementation
create function ufnFindTerritory(@Year int , @Month int , @ProductName nvarchar(20))
returns Table
as
return
(
			select Product.ProductName , Country , SalesOrderHeader.OrderDate
			from SalesOrderHeader 
					inner join SalesOrderDetail on SalesOrderDetail.SalesOrderID=SalesOrderHeader.SalesOrderID
					inner join Product on SalesOrderDetail.ProductID=Product.ProductID
					inner join Customer on Customer.CustomerID=SalesOrderHeader.CustomerID
					inner join Territory on  Customer.TerritoryID=Territory.TerritoryID
			where   ProductName=@ProductName 
						and year(SalesOrderHeader.OrderDate)=@Year 
						and month(SalesOrderHeader.OrderDate)=@Month
);
GO

create function ufnShamciDate(@date char(10))
returns varchar(50)
as
begin
	if(len(@date)<>10 or SUBSTRING(@date,5,1)<>'/' or SUBSTRING(@date,8,1)<>'/') 
		return 'Wrong Format';
	if(SUBSTRING(@date,6,2) = '01')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Farvardin Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '02')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Ordibehesht Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '03')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Khordad Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '04')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Tir Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '05')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Mordad Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '06')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Shahrivar Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '07')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Mehr Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '08')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Aban Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '09')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Azar Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '10')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Dey Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '11')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Bahman Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	if(SUBSTRING(@date,6,2) = '12')
		return CONCAT(CONCAT(CONCAT(SUBSTRING(@date,9,2),' Esfand Mah'),SUBSTRING(@date,1,4)),' Shamci ');
	return 'ERROR'
end;
GO

CREATE FUNCTION ufnGetSalesOrderStatusText(@Status [tinyint])
RETURNS [nvarchar](15) 
AS 
-- Returns the sales order status text representation for the status value.
BEGIN
    DECLARE @ret [nvarchar](15);

    SET @ret = 
        CASE @Status
            WHEN 1 THEN 'In process'
            WHEN 2 THEN 'Approved'
            WHEN 3 THEN 'Backordered'
            WHEN 4 THEN 'Rejected'
            WHEN 5 THEN 'Shipped'
            WHEN 6 THEN 'Cancelled'
            ELSE '** Invalid **'
        END;
    
    RETURN @ret
END;
GO
