-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER UpdateLog
	ON Product
   AFTER UPDATE
AS 
BEGIN
		DECLARE @ModificationType VARCHAR(70);

		IF UPDATE([ProductID])
		BEGIN
		SET @ModificationType = 'ProductID Updated'
		END

		IF UPDATE([ProductName])
		BEGIN
		SET @ModificationType = 'ProductName Updated'
		END
					
		IF UPDATE([CategoryID])
		BEGIN
		SET @ModificationType = 'CategoryID Updated'
		END

		IF UPDATE([BrandName])
		BEGIN
		SET @ModificationType = 'BrandName Updated'
		END

		IF UPDATE([ProductColor])
		BEGIN
		SET @ModificationType = 'ProductColor Updated'
		END

		IF UPDATE([ProductSize])
		BEGIN
		SET @ModificationType = 'ProductSize Updated'
		END

		IF UPDATE([ProductWeight])
		BEGIN
		SET @ModificationType = 'ProductWeight Updated'
		END

		IF UPDATE([Price])
		BEGIN
		SET @ModificationType = 'Price Updated'
		END

		IF UPDATE([UsersOpinionID])
		BEGIN
		SET @ModificationType = 'UsersOpinionID Updated'
		END

		IF UPDATE([Likes])
		BEGIN
		SET @ModificationType = 'Like Number has Updated'
		END

		IF UPDATE([Dislikes])
		BEGIN
		SET @ModificationType = 'Dislike Number has Updated'
		END

		INSERT INTO ProductLog
		SELECT   [ProductID]
					  ,[ProductName]
					  ,[CategoryID]
					  ,[BrandName]
					  ,[ProductColor]
					  ,[ProductSize]
					  ,[ProductWeight]
					  ,[Price]
					  ,[UsersOpinionID]
					  ,[Likes]
					  ,[Dislikes] 
					   ,@ModificationType
		FROM inserted
END
GO
