-- ================================================
-- Template generated from Template Explorer using:
-- Create Trigger (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- See additional Create Trigger templates for more
-- examples of different Trigger statements.
--
-- This block of comments will not be included in
-- the definition of the function.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE TRIGGER iduSalesOrderDetail 
	ON SalesOrderDetail
	AFTER INSERT, DELETE, UPDATE 
AS 
BEGIN
    DECLARE @Count int;

    SET @Count = @@ROWCOUNT;
    IF @Count = 0 
        RETURN;

	 SET NOCOUNT ON;

    BEGIN
        -- If inserting or updating these columns
        IF UPDATE([ProductID]) OR UPDATE([OrderQty]) OR UPDATE([UnitPrice])
        -- Insert record into TransactionHistory
			BEGIN
				INSERT INTO TransactionHistory
					([ProductID]
					,[ReferenceOrderID]
					,[ReferenceOrderLineID]
					,[TransactionType]
					,[TransactionDate]
					,[Quantity]
					,[ActualCost])
				SELECT 
					 inserted.[ProductID]
					,inserted.[SalesOrderID]
					,inserted.[SalesOrderDetailID]
					,'S'
					,GETDATE()
					,inserted.[OrderQty]
					,inserted.[UnitPrice]
				FROM inserted 
					INNER JOIN SalesOrderHeader
					ON inserted.[SalesOrderID] = SalesOrderHeader.[SalesOrderID];
			END;
		UPDATE SalesOrderHeader
			SET SalesOrderHeader.[SubTotal] = 
				(SELECT SUM(SalesOrderDetail.LineTotal)
					FROM SalesOrderDetail
					WHERE SalesOrderHeader.[SalesOrderID] = SalesOrderDetail.[SalesOrderID])
			WHERE SalesOrderHeader.[SalesOrderID] IN (SELECT inserted.[SalesOrderID] FROM inserted);
	END;
END
GO