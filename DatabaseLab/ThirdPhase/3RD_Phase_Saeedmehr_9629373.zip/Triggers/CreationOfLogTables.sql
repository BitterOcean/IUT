
----Creation of Log Tables
CREATE TABLE ProductLog(
	[ProductID] [int] NOT NULL,
	[ProductName] [varchar](20) NULL,
	[CategoryID] [int] NULL,
	[BrandName] [varchar](10) NULL,
	[ProductColor] [varchar](10) NULL,
	[ProductSize] [varchar](10) NULL,
	[ProductWeight] [decimal](7, 3) NULL,
	[Price] [decimal](6, 2) NULL,
	[UsersOpinionID] [int] NULL,
	[Likes] [int] NULL,
	[Dislikes] [int] NULL,
	[ModificationType] [nvarchar](70) NULL
)
GO

CREATE TABLE TransactionHistory(
		[TransactionID] [int] IDENTITY(100000,1) NOT NULL,
		[ProductID] [int] NOT NULL,
		[ReferenceOrderID] [int] NOT NULL,
		[ReferenceOrderLineID] [int] NOT NULL,
		[TransactionDate] [datetime] NOT NULL,
		[TransactionType] [nchar](1) NOT NULL,
		[Quantity] [int] NOT NULL,
		[ActualCost] [money] NOT NULL,
		[ModifiedDate] [datetime] NOT NULL
		)
GO

