-- ============== Editing Tables ================== --
ALTER TABLE dbo.Product
DROP COLUMN UsersOpinionID
GO
-- ================================
ALTER TABLE dbo.ProductLog
DROP COLUMN UsersOpinionID
GO
-- ================================
ALTER TABLE dbo.Product
ADD  quantity int
GO
-- ================================
ALTER TABLE dbo.ProductLog
ADD  quantity int
GO
-- ================================
DROP TABLE dbo.TransactionHistory
GO
-- =============== Editing Functions ================= --
DROP FUNCTION [dbo].[ufnShamciDate]
GO
-- ================================
CREATE FUNCTION dbo.ufnIsCustomerAvailable (@name  varchar(20),@lastname varchar(20))
RETURNS int
AS
BEGIN
	IF(EXISTS(SELECT *
		FROM Customer
		WHERE FirstName=@name AND LastName=@lastname))
		RETURN 1
	RETURN 0
END
GO
-- ================================
CREATE FUNCTION dbo.ufnGetTerritoryID(@country varchar(20),@city varchar(30))
RETURNS int
AS
BEGIN
	DECLARE @RET INT
	SELECT @RET=TerritoryID FROM Territory WHERE  Country=@country AND City=@city
	RETURN @RET
END
GO
-- ================================
CREATE FUNCTION [dbo].[ufnGetGenderText](@Gender [tinyint])
RETURNS [nvarchar](6) 
AS 
BEGIN
    DECLARE @ret [nvarchar](6);

    SET @ret = 
        CASE @Gender
            WHEN 0 THEN 'Female'
            WHEN 1 THEN 'male'
            ELSE '** Invalid **'
        END;
    
    RETURN @ret
END;
GO
-- =============== Editing Triggers ================== --
DROP TRIGGER [dbo].[UpdateLog]
GO
-- ================================
CREATE TRIGGER [dbo].[UpdateLog]
	ON [dbo].[Product]
   AFTER UPDATE
AS 
BEGIN
	DECLARE @ModificationType VARCHAR(70);

	IF UPDATE([ProductID])
	BEGIN
	SET @ModificationType = 'ProductID Updated'
	END

	IF UPDATE([ProductName])
	BEGIN
	SET @ModificationType = 'ProductName Updated'
	END
				
	IF UPDATE([CategoryID])
	BEGIN
	SET @ModificationType = 'CategoryID Updated'
	END

	IF UPDATE([BrandName])
	BEGIN
	SET @ModificationType = 'BrandName Updated'
	END

	IF UPDATE([ProductColor])
	BEGIN
	SET @ModificationType = 'ProductColor Updated'
	END

	IF UPDATE([ProductSize])
	BEGIN
	SET @ModificationType = 'ProductSize Updated'
	END

	IF UPDATE([ProductWeight])
	BEGIN
	SET @ModificationType = 'ProductWeight Updated'
	END

	IF UPDATE([Price])
	BEGIN
	SET @ModificationType = 'Price Updated'
	END

	IF UPDATE([Likes])
	BEGIN
	SET @ModificationType = 'Like Number has Updated'
	END

	IF UPDATE([Dislikes])
	BEGIN
	SET @ModificationType = 'Dislike Number has Updated'
	END

	IF UPDATE([Quantity])
	BEGIN
	SET @ModificationType = 'Quantity has Updated'
	END

	INSERT INTO ProductLog
	SELECT   [ProductID]
		  ,[ProductName]
		  ,[CategoryID]
		  ,[BrandName]
		  ,[ProductColor]
		  ,[ProductSize]
		  ,[ProductWeight]
		  ,[Price]
		  ,[Likes]
		  ,[Dislikes] 
		   ,@ModificationType
		   ,[Quantity]
	FROM inserted
END
GO
-- ================================
DROP TRIGGER [dbo].[DeleteLog]
GO
-- ================================
DROP TRIGGER [dbo].[InsertLog]
GO
-- ================================
CREATE TRIGGER [dbo].[DeleteLog]
	ON [DigiKala].[dbo].[Product]
	AFTER DELETE 
AS
BEGIN
	SET NOCOUNT ON;

		INSERT INTO ProductLog 
		SELECT   [ProductID]
			  ,[ProductName]
			  ,[CategoryID]
			  ,[BrandName]
			  ,[ProductColor]
			  ,[ProductSize]
			  ,[ProductWeight]
			  ,[Price]
			  ,[Likes]
			  ,[Dislikes] 
			  ,'Deleted'
			  ,[Quantity]
		FROM deleted
END
GO
-- ================================
CREATE TRIGGER [dbo].[InsertLog]
	ON [DigiKala].[dbo].[Product]
	AFTER INSERT 
AS
BEGIN
	SET NOCOUNT ON;

		INSERT INTO ProductLog 
		SELECT   [ProductID]
			  ,[ProductName]
			  ,[CategoryID]
			  ,[BrandName]
			  ,[ProductColor]
			  ,[ProductSize]
			  ,[ProductWeight]
			  ,[Price]
			  ,[Likes]
			  ,[Dislikes] 
			  ,'Insertes'
			  ,[Quantity]
		FROM inserted
END
GO
-- =============== Editing Stored Procedure ================== --
DROP PROCEDURE [dbo].[uspFindWordInComments]
GO
-- ================================
DROP PROCEDURE [dbo].[uspProductInfo]
GO
-- ================================
DROP PROCEDURE [dbo].[uspGetCustomerInfo]
GO
-- ================================
CREATE PROCEDURE [dbo].[uspProductList]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT ProductID
		,ProductName
		,CategoryName
		,BrandName
		,ProductColor
		,ProductSize
		,ProductWeight
		,Price
		,Explanation
		,Likes
		,Dislikes
	FROM Product INNER JOIN Category ON (Product.CategoryID=Category.CategoryID)
END
GO
-- ================================
CREATE PROCEDURE dbo.uspSignup
	@firstname varchar(20),
	@lastname varchar(20),
	@gender bit,
	@phone varchar(13),
	@country varchar(20),
	@city varchar(30),
	@addr varchar(100),
	@post varchar(10)

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @TerritoryID INT
	SELECT @TerritoryID=dbo.ufnGetTerritoryID(@country,@city)
	INSERT INTO Customer
	VALUES (@firstname,@lastname,@gender,@phone,@TerritoryID,@addr,@post);
END
GO
-- ================================
CREATE PROCEDURE dbo.uspCommentList
	@productID int

AS
BEGIN
	SET NOCOUNT ON;
	SELECT ProductID,FirstName,LastName,CommentText, CASE 
							   WHEN Recomended=1 THEN 'Yes' 
							   WHEN Recomended=0 THEN  'No'
							   END AS Recomended , Advantages,Disadvantages,CommentTime							
	FROM Comments INNER JOIN Customer ON (Comments.CommentID=Customer.CustomerID)
	WHERE ProductID=@productID
END
GO
-- ================================
CREATE PROCEDURE dbo.uspBasketShow
	@salesOrderID int 
AS
BEGIN
	SET NOCOUNT ON;
	SELECT SalesOrderDetailID AS ID,ProductName,OrderQty AS Quantity,UnitPrice,LineTotal
	FROM SalesOrderDetail INNER JOIN Product
		ON SalesOrderDetail.ProductID=Product.ProductID
	WHERE SalesOrderID=@salesOrderID
END
GO
-- ================================
CREATE PROCEDURE dbo.uspSubTotal
	@salesOrderID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Sub INT
	SELECT @Sub=SUM(LineTotal)
	FROM SalesOrderDetail
	WHERE SalesOrderID=@salesOrderID

	UPDATE SalesOrderHeader
	SET SubTotal = @Sub , DueTotal=@Sub
	WHERE SalesOrderID=@salesOrderID
	
END
GO
-- ================================
