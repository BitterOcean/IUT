#include "loginsignup.h"
#include "ui_loginsignup.h"
#include <QMessageBox>

LoginSignup::LoginSignup(QWidget *parent)
  : QMainWindow(parent)
  , ui(new Ui::LoginSignup)
  , mMain(new MainWindow(parent))
{
    ui->setupUi(this);
    mDbConnection = new DatabaseConnection("SQL SERVER",
                                           "DESKTOP-B55250I",
                                           "DigiKala",
                                           "Maryam",
                                           "7731",
                                           true);
    QString error;
    if(!mDbConnection->openDatabase(&error))
        QMessageBox::critical(this,"ERROR",error);
    QSqlDatabase db;
    mQuery = new QSqlQuery(db);
}

LoginSignup::~LoginSignup()
{
    delete ui;
}

void LoginSignup::on_SignupButtom_clicked()
{
    if(ui->FirstName->text().isEmpty()
            |ui->LastName->text().isEmpty()
            |ui->Phone->text().isEmpty()
            |ui->Address->toPlainText().isEmpty()
            |ui->PostalCode->text().isEmpty())
         QMessageBox::critical(this,"ERROR","You should fill in all parts! ");
    else
    {
        mQuery->prepare("SELECT DBO.ufnIsCustomerAvailable(:firstname, :lastname) as available");
        mQuery->bindValue(":firstname",ui->FirstName->text());
        mQuery->bindValue(":lastname",ui->LastName->text());
        mQuery->exec();
        if(mQuery->last())
        {
            if(mQuery->value("available").toInt())
            {
                QMessageBox::information(this,"Result","This Customer exists! Try to Login...");
            }
            else// not available
            {
                mQuery->prepare("EXECUTE [dbo].[uspSignup] :firstname,:lastname,:gender,:phone,:country,:city,:addr,:post");
                mQuery->bindValue(":firstname",ui->FirstName->text());
                mQuery->bindValue(":lastname",ui->LastName->text());
                mQuery->bindValue(":gender",ui->Gender->currentText().toInt());
                mQuery->bindValue(":phone",ui->Phone->text());
                mQuery->bindValue(":country",ui->Country->currentText());
                mQuery->bindValue(":city",ui->City->currentText());
                mQuery->bindValue(":addr",ui->Address->toPlainText());
                mQuery->bindValue(":post",ui->PostalCode->text());
                mQuery->exec();
                mQuery->prepare("SELECT CustomerID FROM Customer WHERE FirstName=:firstname AND LastName=:lastname");
                mQuery->bindValue(":firstname",ui->FirstName->text());
                mQuery->bindValue(":lastname",ui->LastName->text());
                mQuery->exec();
                if(mQuery->last())
                {
                    mMain->setCustomerID(mQuery->value("CustomerID").toInt());
                    hide();
                    mMain->show();
                }
                else
                   QMessageBox::critical(this,"ERROR","Something went wrong!...\nTry again.");
            }
        }
    }
    ui->LastName->clear();
    ui->FirstName->clear();
    ui->Address->clear();
    ui->Phone->clear();
    ui->PostalCode->clear();
}

void LoginSignup::on_LoginButtom_clicked()
{
    mQuery->prepare("SELECT DBO.ufnIsCustomerAvailable(:firstname, :lastname) as available");
    mQuery->bindValue(":firstname",ui->FistNameL->text());
    mQuery->bindValue(":lastname",ui->LastNameL->text());
    mQuery->exec();
    if(mQuery->last())
    {
        if(mQuery->value("available").toInt())
        {
            mQuery->prepare("SELECT CustomerID FROM Customer WHERE FirstName=:firstname AND LastName=:lastname");
            mQuery->bindValue(":firstname",ui->FistNameL->text());
            mQuery->bindValue(":lastname",ui->LastNameL->text());
            mQuery->exec();
            if(mQuery->last())
            {
                mMain->setCustomerID(mQuery->value("CustomerID").toInt());
                hide();
                mMain->show();
            }
            else
               QMessageBox::critical(this,"ERROR","Something went wrong!...\nTry again.");
        }
        else// not available
            QMessageBox::information(this,"Result","This Customer does not exist! Try to Sign up...");
    }
    ui->FistNameL->clear();
    ui->LastNameL->clear();
}
