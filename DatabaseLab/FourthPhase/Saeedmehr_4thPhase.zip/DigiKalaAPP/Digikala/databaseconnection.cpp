#include "databaseconnection.h"
#include <QSqlQuery>
#include <QSqlError>

DatabaseConnection::DatabaseConnection(const QString &Driver,
                                       const QString &Server,
                                       const QString &DatabaseName,
                                       const QString &User,
                                       const QString &Password,
                                       bool TrustedConnection)
{
    mDatabase = QSqlDatabase::addDatabase("QODBC");
    mDriver = Driver;
    mServer = Server;
    mDatabaseName = DatabaseName;
    mUser = User;
    mPassword = Password;
    mTrustedConnection = TrustedConnection;
}

bool DatabaseConnection::openDatabase(QString *error)
{
    mDatabase.setDatabaseName(QString("DRIVER={%1};"
                                      "SERVER=%2;"
                                      "DATABASE=%3;"
                                      "UID=%4;"
                                      "PWD=%5;"
                                      "Trusted_Connection=%6;")
                              .arg(mDriver)
                              .arg(mServer)
                              .arg(mDatabaseName)
                              .arg(mUser)
                              .arg(mPassword)
                              .arg(mTrustedConnection ? "Yes" : "No"));
    if(!mDatabase.open())
    {
        if(error != nullptr)
            *error = mDatabase.lastError().text();
        return false;
    }
    return true;
}
