#ifndef LOGINSIGNUP_H
#define LOGINSIGNUP_H

#include <QMainWindow>
#include "mainwindow.h"
#include "databaseconnection.h"
#include <QSqlQuery>


namespace Ui
{
    class LoginSignup;
}

class QSqlQuery;

class LoginSignup : public QMainWindow
{
    Q_OBJECT

public:
    explicit LoginSignup(QWidget *parent = nullptr);
    ~LoginSignup();

private slots:
    void on_SignupButtom_clicked();
    void on_LoginButtom_clicked();

private:
    Ui::LoginSignup *ui;
    MainWindow *mMain;
    DatabaseConnection *mDbConnection;
    QSqlQuery *mQuery;
};

#endif // LOGINSIGNUP_H
