#include "shoppingbasket.h"
#include "ui_shoppingbasket.h"
#include <QMessageBox>

ShoppingBasket::ShoppingBasket(QWidget *parent)
   : QMainWindow(parent)
   , ui(new Ui::ShoppingBasket)
   , mModel(new QSqlQueryModel(parent))
{
    ui->setupUi(this);
    ui->Detail->setModel(mModel);
    QSqlDatabase db;
    mQuery = new QSqlQuery(db);
}

ShoppingBasket::~ShoppingBasket()
{
    delete ui;
}

void ShoppingBasket::setCustomerID(int id)
{
    CustomerID = id;
}

void ShoppingBasket::setSalesOrderHeaderID(int id)
{
    SalesOrderHeaderID = id;
}

void ShoppingBasket::Totalshow()
{
    QString msg("EXEC [dbo].[uspBasketShow] ");
    msg.append(SalesOrderHeaderID);
    mModel->setQuery(msg);
    mQuery->prepare("SELECT FirstName FROM Customer WHERE CustomerID=:id");
    mQuery->bindValue(":id",CustomerID);
    mQuery->exec();
    ui->Firstname->setText(mQuery->value("FirstName").toString());
    mQuery->prepare("SELECT LasttName FROM Customer WHERE CustomerID=:id");
    mQuery->bindValue(":id",CustomerID);
    mQuery->exec();
    ui->Firstname->setText(mQuery->value("LasttName").toString());
    mQuery->prepare("SELECT status from SalesOrderHeader WHERE CustomerID=:id");
    mQuery->bindValue(":id",CustomerID);
    mQuery->exec();
    int Status = mQuery->value("status").toInt();
    mQuery->prepare("SELECT dbo.ufnGetSalesOrderStatusText(:Status) AS Status");
    mQuery->bindValue(":Status",Status);
    mQuery->exec();
    ui->status->setText(mQuery->value("Status").toString());
}

void ShoppingBasket::on_Cancel_clicked()
{
    mQuery->prepare("update SalesOrderHeader set status=6 where SalesOrderID=:id");
    mQuery->bindValue(":id",SalesOrderHeaderID);
    mQuery->exec();
}

void ShoppingBasket::on_pay_clicked()
{
    mQuery->prepare("EXECUTE [dbo].[uspSubTotal] :id");
    mQuery->bindValue(":id",SalesOrderHeaderID);
    mQuery->exec();
    mQuery->prepare("select SubTotal from SalesOrderHeader where SalesOrderID=:id");
    mQuery->bindValue(":id",SalesOrderHeaderID);
    mQuery->exec();
    ui->subtotal->setText(mQuery->value("SubTotal").toString());
    ui->duetotal->setText(mQuery->value("SubTotal").toString());
}

void ShoppingBasket::on_Detail_clicked(const QModelIndex &index)
{
    mQuery->prepare("delete from SalesOrderDetail where SalesOrderDetailID=:pid");
    mQuery->bindValue(":pid",index.siblingAtColumn(0).data().toString());
    mQuery->exec();
    QString msg("EXEC [dbo].[uspBasketShow] ");
    msg.append(SalesOrderHeaderID);
    mModel->setQuery(msg);
}
