#ifndef SHOPPINGBASKET_H
#define SHOPPINGBASKET_H

#include <QMainWindow>
#include <QSqlQuery>
#include <QSqlQueryModel>

namespace Ui
{
    class ShoppingBasket;
}

class ShoppingBasket : public QMainWindow
{
    Q_OBJECT

public:
    explicit ShoppingBasket(QWidget *parent = nullptr);
    ~ShoppingBasket();
    void setSalesOrderHeaderID(int id);
    void setCustomerID(int id);
    void Totalshow();

private slots:
    void on_Cancel_clicked();
    void on_pay_clicked();
    void on_Detail_clicked(const QModelIndex &index);

private:
    Ui::ShoppingBasket *ui;
    int SalesOrderHeaderID;
    int CustomerID;
    QSqlQuery *mQuery;
    QSqlQueryModel *mModel;
};

#endif // SHOPPINGBASKET_H
