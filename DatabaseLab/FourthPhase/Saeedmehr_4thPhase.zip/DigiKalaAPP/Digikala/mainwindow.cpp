#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QSqlQueryModel>
#include "loginsignup.h"
#include <QDateTime>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , basket(new ShoppingBasket(parent))
{
    ui->setupUi(this);
    SalesOrderHeaderID=-1;
    QSqlDatabase db;
    mQuery = new QSqlQuery(db);
    mModel=nullptr;
}

void MainWindow::setCustomerID(int id)
{
    CustomerID = id;
    basket->setCustomerID(id);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionProductList_triggered()
{
    if(mModel==nullptr)
    {
        mModel = new QSqlQueryModel(this);
        ui->tableView->setModel(mModel);
        mModel->setQuery("SELECT * FROM Product");//EXECUTE [dbo].[uspProductList]
    }
    else
    {
        mModel->setQuery("SELECT * FROM Product");
    }
}

void MainWindow::on_actionShoppingBasket_triggered()
{
    hide();
    basket->show();
    basket->Totalshow();
}

void MainWindow::on_actionAbout_QT_triggered()
{
    QMessageBox::aboutQt(this,"QT");
}

void MainWindow::on_actionAbout_Me_triggered()
{
    QMessageBox msgBox;
    msgBox.setText("About Me");
    msgBox.setInformativeText("Name : Maryam Saeedmehr\n"
                              "S.No : 9629373\n"
                              "Telegram : @BitterOcean\n"
                              "Gmail : MaryamSaeedmehr@ec.iut.ac.ir");
    msgBox.exec();
}

void MainWindow::on_tableView_clicked(const QModelIndex &index)
{
    QMessageBox msgBox;
    msgBox.setText("This item is selected");
    msgBox.setInformativeText("Do you want to add this product to your shopping basket?\n"
                              "Also if you want to see customers comments or add one about this product\n"
                              "please press open");
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No | QMessageBox::Open);
    msgBox.setDefaultButton(QMessageBox::Open);
    int ret = msgBox.exec();
    switch (ret)
    {
      case QMessageBox::Yes:
          msgBox.close();
          if(SalesOrderHeaderID==-1)
          {
              mQuery->prepare("INSERT INTO SalesOrderHeader VALUES(@status,@orderDate,@customerID,@subTotal,@DueTotal)");
              mQuery->bindValue("@status",1);
              mQuery->bindValue("@orderDate",QDateTime::currentDateTime());
              mQuery->bindValue("@customerID",CustomerID);
              mQuery->bindValue("@subTotal",0);
              mQuery->bindValue("@DueTotal",0);
              mQuery->exec();
              mQuery->prepare("SELECT TOP (1) SalesOrderID FROM SalesOrderHeader ORDER BY OrderDate DESC");
              mQuery->exec();
              SalesOrderHeaderID = mQuery->value("SalesOrderID").toInt();
              basket->setSalesOrderHeaderID(SalesOrderHeaderID);
          }
          productID = index.siblingAtColumn(0).data().toInt();
          mQuery->prepare("INSERT INTO SalesOrderDetail VALUES(@SalesOrderID,@productid,@qty,@price,@ltotal)");
          mQuery->bindValue("@SalesOrderID",SalesOrderHeaderID);
          mQuery->bindValue("@productid",productID);
          mQuery->bindValue("@qty",1);
          mQuery->bindValue("@price",index.siblingAtColumn(7).data().toInt());
          mQuery->bindValue("@ltotal",index.siblingAtColumn(7).data().toInt());
          mQuery->exec();
          break;
      case QMessageBox::No:
          msgBox.close();
          break;
      case QMessageBox::Open:
          msgBox.close();
          QString msg("EXECUTE [dbo].[uspCommentList] ");
          msg.append(index.siblingAtColumn(0).data().toString());
          mModel->setQuery(msg);
          break;
    }
}

void MainWindow::on_Send_clicked()
{
    if(!ui->comment->text().isEmpty())
    {
        mQuery->prepare("insert into Comments values(@productID,@customerID,@commentText,@rec,@adv,@disadv,@time)");
        mQuery->bindValue("@productID",productID);
        mQuery->bindValue("@customerID",CustomerID);
        mQuery->bindValue("@commentText",ui->comment->text());
        mQuery->bindValue("@rec",ui->checkBox->isChecked());
        mQuery->bindValue("@adv",ui->Advantages->text());
        mQuery->bindValue("@disadv",ui->Disadvantages->text());
        mQuery->bindValue("@time",QDateTime::currentDateTime());
        mQuery->exec();
    }
}
