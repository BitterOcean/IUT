#ifndef DATABASECONNECTION_H
#define DATABASECONNECTION_H

#include <QSqlDatabase>

class DatabaseConnection
{
public:
    DatabaseConnection(const QString &Driver,
                        const QString &Server,
                        const QString &DatabaseName,
                        const QString &User,
                        const QString &Password,
                        bool TrustedConnection = true);
    bool openDatabase(QString *error = nullptr);

private:
    QSqlDatabase mDatabase;
    QString mDriver;
    QString mServer;
    QString mDatabaseName;
    QString mUser;
    QString mPassword;
    bool mTrustedConnection;
};

#endif // DATABASECONNECTION_H
