#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlQuery>
#include "shoppingbasket.h"

namespace Ui
{
    class MainWindow;
}

class QSqlQueryModel;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void setCustomerID(int id);

private slots:
    void on_actionProductList_triggered();
    void on_actionShoppingBasket_triggered();
    void on_actionAbout_QT_triggered();
    void on_actionAbout_Me_triggered();
    void on_tableView_clicked(const QModelIndex &index);
    void on_Send_clicked();

private:
    Ui::MainWindow *ui;
    QSqlQueryModel *mModel;
    int SalesOrderHeaderID;
    int CustomerID;
    QSqlQuery *mQuery;
    int productID;
    ShoppingBasket *basket;
};

#endif // MAINWINDOW_H
