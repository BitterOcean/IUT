/********************************************************************************
** Form generated from reading UI file 'buydialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BUYDIALOG_H
#define UI_BUYDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_BuyDialog
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer_7;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer_8;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_2;
    QLabel *label;
    QSpacerItem *verticalSpacer_3;
    QLabel *label_2;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_5;
    QLineEdit *FirstName;
    QSpacerItem *verticalSpacer_4;
    QLineEdit *LastName;
    QSpacerItem *verticalSpacer_6;
    QLabel *label_3;
    QPushButton *OK;
    QPushButton *Cancel;

    void setupUi(QDialog *BuyDialog)
    {
        if (BuyDialog->objectName().isEmpty())
            BuyDialog->setObjectName(QString::fromUtf8("BuyDialog"));
        BuyDialog->resize(532, 310);
        BuyDialog->setMinimumSize(QSize(532, 310));
        BuyDialog->setMaximumSize(QSize(532, 310));
        BuyDialog->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        gridLayout = new QGridLayout(BuyDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_7, 3, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 4, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_8, 1, 0, 1, 2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        label = new QLabel(BuyDialog);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(12);
        label->setFont(font);

        verticalLayout_2->addWidget(label);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_3);

        label_2 = new QLabel(BuyDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);

        verticalLayout_2->addWidget(label_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_5);

        FirstName = new QLineEdit(BuyDialog);
        FirstName->setObjectName(QString::fromUtf8("FirstName"));
        FirstName->setFont(font);
        FirstName->setAutoFillBackground(false);
        FirstName->setFrame(true);
        FirstName->setDragEnabled(true);
        FirstName->setClearButtonEnabled(false);

        verticalLayout->addWidget(FirstName);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        LastName = new QLineEdit(BuyDialog);
        LastName->setObjectName(QString::fromUtf8("LastName"));
        LastName->setFont(font);
        LastName->setAutoFillBackground(false);
        LastName->setDragEnabled(true);

        verticalLayout->addWidget(LastName);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_6);


        horizontalLayout->addLayout(verticalLayout);


        gridLayout->addLayout(horizontalLayout, 2, 0, 1, 3);

        label_3 = new QLabel(BuyDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);

        gridLayout->addWidget(label_3, 0, 0, 1, 1);

        OK = new QPushButton(BuyDialog);
        OK->setObjectName(QString::fromUtf8("OK"));

        gridLayout->addWidget(OK, 4, 1, 1, 1);

        Cancel = new QPushButton(BuyDialog);
        Cancel->setObjectName(QString::fromUtf8("Cancel"));

        gridLayout->addWidget(Cancel, 4, 2, 1, 1);


        retranslateUi(BuyDialog);

        QMetaObject::connectSlotsByName(BuyDialog);
    } // setupUi

    void retranslateUi(QDialog *BuyDialog)
    {
        BuyDialog->setWindowTitle(QApplication::translate("BuyDialog", "Dialog", nullptr));
        label->setText(QApplication::translate("BuyDialog", "First Name *", nullptr));
        label_2->setText(QApplication::translate("BuyDialog", "Last Name *", nullptr));
        FirstName->setInputMask(QString());
        FirstName->setText(QString());
        LastName->setText(QString());
        label_3->setText(QApplication::translate("BuyDialog", "Please Fill in the Blanks ", nullptr));
        OK->setText(QApplication::translate("BuyDialog", "OK", nullptr));
        Cancel->setText(QApplication::translate("BuyDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BuyDialog: public Ui_BuyDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BUYDIALOG_H
