/********************************************************************************
** Form generated from reading UI file 'shoppingbasket.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGBASKET_H
#define UI_SHOPPINGBASKET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingBasket
{
public:
    QWidget *centralwidget;
    QWidget *widget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout_2;
    QLabel *label_5;
    QLineEdit *subtotal;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *duetotal;
    QPushButton *pay;
    QPushButton *Cancel;
    QGridLayout *gridLayout;
    QLineEdit *Firstname;
    QLabel *label_3;
    QLabel *label;
    QLineEdit *Lastname;
    QLabel *label_2;
    QLineEdit *status;
    QSpacerItem *horizontalSpacer;
    QTableView *Detail;

    void setupUi(QMainWindow *ShoppingBasket)
    {
        if (ShoppingBasket->objectName().isEmpty())
            ShoppingBasket->setObjectName(QString::fromUtf8("ShoppingBasket"));
        ShoppingBasket->resize(818, 621);
        ShoppingBasket->setMinimumSize(QSize(818, 621));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Images/DigikalaIcone.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        ShoppingBasket->setWindowIcon(icon);
        ShoppingBasket->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        centralwidget = new QWidget(ShoppingBasket);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 781, 581));
        gridLayout_3 = new QGridLayout(widget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label_5->setFont(font);

        gridLayout_2->addWidget(label_5, 1, 0, 1, 1);

        subtotal = new QLineEdit(widget);
        subtotal->setObjectName(QString::fromUtf8("subtotal"));
        QFont font1;
        font1.setPointSize(12);
        subtotal->setFont(font1);
        subtotal->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        subtotal->setReadOnly(true);

        gridLayout_2->addWidget(subtotal, 0, 1, 1, 1);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);

        gridLayout_2->addWidget(label_4, 0, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 0, 3, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_3, 0, 2, 1, 1);

        duetotal = new QLineEdit(widget);
        duetotal->setObjectName(QString::fromUtf8("duetotal"));
        duetotal->setFont(font1);
        duetotal->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        duetotal->setReadOnly(true);

        gridLayout_2->addWidget(duetotal, 1, 1, 1, 1);

        pay = new QPushButton(widget);
        pay->setObjectName(QString::fromUtf8("pay"));
        pay->setFont(font);

        gridLayout_2->addWidget(pay, 2, 2, 1, 1);

        Cancel = new QPushButton(widget);
        Cancel->setObjectName(QString::fromUtf8("Cancel"));
        Cancel->setFont(font);

        gridLayout_2->addWidget(Cancel, 2, 3, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 3, 0, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        Firstname = new QLineEdit(widget);
        Firstname->setObjectName(QString::fromUtf8("Firstname"));
        Firstname->setFont(font1);
        Firstname->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        Firstname->setReadOnly(true);

        gridLayout->addWidget(Firstname, 0, 1, 1, 1);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);

        gridLayout->addWidget(label_3, 1, 0, 1, 1);

        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font);

        gridLayout->addWidget(label, 0, 3, 1, 1);

        Lastname = new QLineEdit(widget);
        Lastname->setObjectName(QString::fromUtf8("Lastname"));
        Lastname->setFont(font1);
        Lastname->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        Lastname->setReadOnly(true);

        gridLayout->addWidget(Lastname, 1, 1, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        status = new QLineEdit(widget);
        status->setObjectName(QString::fromUtf8("status"));
        status->setFont(font1);
        status->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        status->setReadOnly(true);

        gridLayout->addWidget(status, 0, 4, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 2, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 0, 1, 1);

        Detail = new QTableView(widget);
        Detail->setObjectName(QString::fromUtf8("Detail"));
        Detail->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_3->addWidget(Detail, 1, 0, 1, 1);

        ShoppingBasket->setCentralWidget(centralwidget);

        retranslateUi(ShoppingBasket);

        QMetaObject::connectSlotsByName(ShoppingBasket);
    } // setupUi

    void retranslateUi(QMainWindow *ShoppingBasket)
    {
        ShoppingBasket->setWindowTitle(QApplication::translate("ShoppingBasket", "DigiKala", nullptr));
        label_5->setText(QApplication::translate("ShoppingBasket", "DueTotal :", nullptr));
        label_4->setText(QApplication::translate("ShoppingBasket", "SubTotal :", nullptr));
        pay->setText(QApplication::translate("ShoppingBasket", "Pay", nullptr));
        Cancel->setText(QApplication::translate("ShoppingBasket", "Cancel", nullptr));
        label_3->setText(QApplication::translate("ShoppingBasket", "Last Name :", nullptr));
        label->setText(QApplication::translate("ShoppingBasket", "Status :", nullptr));
        label_2->setText(QApplication::translate("ShoppingBasket", "First Name :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoppingBasket: public Ui_ShoppingBasket {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGBASKET_H
