/********************************************************************************
** Form generated from reading UI file 'loginsignup.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINSIGNUP_H
#define UI_LOGINSIGNUP_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginSignup
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTabWidget *tabWidget;
    QWidget *Signup;
    QGridLayout *gridLayout_2;
    QLineEdit *LastName;
    QLineEdit *Phone;
    QComboBox *Gender;
    QComboBox *City;
    QLabel *label_5;
    QLineEdit *PostalCode;
    QLabel *label;
    QLabel *label_7;
    QTextEdit *Address;
    QLabel *label_3;
    QLabel *label_8;
    QComboBox *Country;
    QLineEdit *FirstName;
    QLabel *label_4;
    QLabel *label_6;
    QLabel *label_9;
    QPushButton *SignupButtom;
    QWidget *Login;
    QGridLayout *gridLayout_5;
    QGridLayout *gridLayout_4;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_18;
    QLineEdit *FistNameL;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_19;
    QLineEdit *LastNameL;
    QPushButton *LoginButtom;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QMainWindow *LoginSignup)
    {
        if (LoginSignup->objectName().isEmpty())
            LoginSignup->setObjectName(QString::fromUtf8("LoginSignup"));
        LoginSignup->resize(818, 621);
        LoginSignup->setMinimumSize(QSize(818, 621));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Images/DigikalaIcone.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        LoginSignup->setWindowIcon(icon);
        LoginSignup->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        centralwidget = new QWidget(LoginSignup);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8(""));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QFont font;
        font.setFamily(QString::fromUtf8("Mongolian Baiti"));
        font.setPointSize(20);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        tabWidget->setFont(font);
        tabWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Rounded);
        Signup = new QWidget();
        Signup->setObjectName(QString::fromUtf8("Signup"));
        Signup->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        gridLayout_2 = new QGridLayout(Signup);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        LastName = new QLineEdit(Signup);
        LastName->setObjectName(QString::fromUtf8("LastName"));
        QFont font1;
        font1.setPointSize(12);
        LastName->setFont(font1);
        LastName->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(LastName, 1, 1, 1, 1);

        Phone = new QLineEdit(Signup);
        Phone->setObjectName(QString::fromUtf8("Phone"));
        Phone->setFont(font1);
        Phone->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(Phone, 2, 1, 1, 1);

        Gender = new QComboBox(Signup);
        Gender->addItem(QString());
        Gender->addItem(QString());
        Gender->setObjectName(QString::fromUtf8("Gender"));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        Gender->setFont(font2);
        Gender->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        Gender->setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);

        gridLayout_2->addWidget(Gender, 3, 1, 1, 1);

        City = new QComboBox(Signup);
        City->addItem(QString());
        City->addItem(QString());
        City->addItem(QString());
        City->addItem(QString());
        City->addItem(QString());
        City->addItem(QString());
        City->setObjectName(QString::fromUtf8("City"));
        City->setFont(font2);
        City->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(City, 4, 1, 1, 1);

        label_5 = new QLabel(Signup);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font2);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_5, 6, 0, 1, 1);

        PostalCode = new QLineEdit(Signup);
        PostalCode->setObjectName(QString::fromUtf8("PostalCode"));
        PostalCode->setFont(font1);
        PostalCode->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(PostalCode, 7, 1, 1, 1);

        label = new QLabel(Signup);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font2);
        label->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        label_7 = new QLabel(Signup);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font2);
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_7, 7, 0, 1, 1);

        Address = new QTextEdit(Signup);
        Address->setObjectName(QString::fromUtf8("Address"));
        Address->setFont(font1);
        Address->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(Address, 6, 1, 1, 1);

        label_3 = new QLabel(Signup);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font2);
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_3, 1, 0, 1, 1);

        label_8 = new QLabel(Signup);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font2);
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_8, 4, 0, 1, 1);

        Country = new QComboBox(Signup);
        Country->addItem(QString());
        Country->addItem(QString());
        Country->setObjectName(QString::fromUtf8("Country"));
        Country->setFont(font2);
        Country->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(Country, 5, 1, 1, 1);

        FirstName = new QLineEdit(Signup);
        FirstName->setObjectName(QString::fromUtf8("FirstName"));
        FirstName->setFont(font1);
        FirstName->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(FirstName, 0, 1, 1, 1);

        label_4 = new QLabel(Signup);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font2);
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_4, 2, 0, 1, 1);

        label_6 = new QLabel(Signup);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font2);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_6, 3, 0, 1, 1);

        label_9 = new QLabel(Signup);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setFont(font2);
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_9->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_9, 5, 0, 1, 1);

        SignupButtom = new QPushButton(Signup);
        SignupButtom->setObjectName(QString::fromUtf8("SignupButtom"));
        QFont font3;
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setItalic(true);
        font3.setWeight(75);
        SignupButtom->setFont(font3);
        SignupButtom->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout_2->addWidget(SignupButtom, 8, 1, 1, 1);

        tabWidget->addTab(Signup, QString());
        Login = new QWidget();
        Login->setObjectName(QString::fromUtf8("Login"));
        gridLayout_5 = new QGridLayout(Login);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer_2, 1, 2, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_4->addItem(verticalSpacer, 2, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        label_18 = new QLabel(Login);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setFont(font2);
        label_18->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_18);

        FistNameL = new QLineEdit(Login);
        FistNameL->setObjectName(QString::fromUtf8("FistNameL"));
        FistNameL->setFont(font1);
        FistNameL->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout_2->addWidget(FistNameL);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        label_19 = new QLabel(Login);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setFont(font2);
        label_19->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label_19);

        LastNameL = new QLineEdit(Login);
        LastNameL->setObjectName(QString::fromUtf8("LastNameL"));
        LastNameL->setFont(font1);
        LastNameL->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        horizontalLayout->addWidget(LastNameL);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout_4->addLayout(verticalLayout, 0, 0, 1, 1);

        LoginButtom = new QPushButton(Login);
        LoginButtom->setObjectName(QString::fromUtf8("LoginButtom"));
        LoginButtom->setFont(font3);

        gridLayout_4->addWidget(LoginButtom, 2, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 0, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_2, 2, 1, 1, 1);


        gridLayout_5->addLayout(gridLayout_4, 0, 0, 1, 1);

        tabWidget->addTab(Login, QString());

        gridLayout->addWidget(tabWidget, 0, 1, 1, 1);

        LoginSignup->setCentralWidget(centralwidget);

        retranslateUi(LoginSignup);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(LoginSignup);
    } // setupUi

    void retranslateUi(QMainWindow *LoginSignup)
    {
        LoginSignup->setWindowTitle(QApplication::translate("LoginSignup", "DigiKala", nullptr));
        Gender->setItemText(0, QApplication::translate("LoginSignup", "Female", nullptr));
        Gender->setItemText(1, QApplication::translate("LoginSignup", "Male", nullptr));

        City->setItemText(0, QApplication::translate("LoginSignup", "Isfahan", nullptr));
        City->setItemText(1, QApplication::translate("LoginSignup", "NewYork", nullptr));
        City->setItemText(2, QApplication::translate("LoginSignup", "LosAngeles", nullptr));
        City->setItemText(3, QApplication::translate("LoginSignup", "Tehran", nullptr));
        City->setItemText(4, QApplication::translate("LoginSignup", "Shiraz", nullptr));
        City->setItemText(5, QApplication::translate("LoginSignup", "Hamedan", nullptr));

        label_5->setText(QApplication::translate("LoginSignup", "Address", nullptr));
        label->setText(QApplication::translate("LoginSignup", "First Name", nullptr));
        label_7->setText(QApplication::translate("LoginSignup", "Postal Code", nullptr));
        label_3->setText(QApplication::translate("LoginSignup", "Last Name", nullptr));
        label_8->setText(QApplication::translate("LoginSignup", "City", nullptr));
        Country->setItemText(0, QApplication::translate("LoginSignup", "Iran", nullptr));
        Country->setItemText(1, QApplication::translate("LoginSignup", "USA", nullptr));

        label_4->setText(QApplication::translate("LoginSignup", "Phone Number", nullptr));
        label_6->setText(QApplication::translate("LoginSignup", "Gender", nullptr));
        label_9->setText(QApplication::translate("LoginSignup", "Country", nullptr));
        SignupButtom->setText(QApplication::translate("LoginSignup", "Register Me", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Signup), QApplication::translate("LoginSignup", "Sign Up", nullptr));
        label_18->setText(QApplication::translate("LoginSignup", "First Name *", nullptr));
        label_19->setText(QApplication::translate("LoginSignup", "Last Name *", nullptr));
        LoginButtom->setText(QApplication::translate("LoginSignup", "Login", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Login), QApplication::translate("LoginSignup", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginSignup: public Ui_LoginSignup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINSIGNUP_H
