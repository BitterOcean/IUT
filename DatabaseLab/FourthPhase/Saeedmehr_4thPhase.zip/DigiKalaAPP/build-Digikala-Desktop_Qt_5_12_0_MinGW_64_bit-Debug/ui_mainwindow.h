/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionProductList;
    QAction *actionShoppingBasket;
    QAction *actionAbout_QT;
    QAction *actionAbout_Me;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLineEdit *Advantages;
    QCheckBox *checkBox;
    QLineEdit *Disadvantages;
    QLabel *label;
    QTableView *tableView;
    QLineEdit *comment;
    QLabel *label_2;
    QPushButton *Send;
    QMenuBar *menuBar;
    QMenu *menuOptions;
    QMenu *menuAbout;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(832, 636);
        MainWindow->setMinimumSize(QSize(818, 621));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        MainWindow->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Images/DigikalaIcone.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        actionProductList = new QAction(MainWindow);
        actionProductList->setObjectName(QString::fromUtf8("actionProductList"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Images/ProductList.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionProductList->setIcon(icon1);
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        actionProductList->setFont(font1);
        actionShoppingBasket = new QAction(MainWindow);
        actionShoppingBasket->setObjectName(QString::fromUtf8("actionShoppingBasket"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Images/shopping.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionShoppingBasket->setIcon(icon2);
        actionShoppingBasket->setFont(font1);
        actionAbout_QT = new QAction(MainWindow);
        actionAbout_QT->setObjectName(QString::fromUtf8("actionAbout_QT"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Images/qt.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_QT->setIcon(icon3);
        actionAbout_QT->setFont(font1);
        actionAbout_Me = new QAction(MainWindow);
        actionAbout_Me->setObjectName(QString::fromUtf8("actionAbout_Me"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Images/Aboutme.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_Me->setIcon(icon4);
        actionAbout_Me->setFont(font1);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setEnabled(true);
        centralWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
""));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        Advantages = new QLineEdit(centralWidget);
        Advantages->setObjectName(QString::fromUtf8("Advantages"));

        gridLayout->addWidget(Advantages, 2, 1, 1, 1);

        checkBox = new QCheckBox(centralWidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setFont(font1);

        gridLayout->addWidget(checkBox, 1, 2, 1, 1);

        Disadvantages = new QLineEdit(centralWidget);
        Disadvantages->setObjectName(QString::fromUtf8("Disadvantages"));

        gridLayout->addWidget(Disadvantages, 3, 1, 1, 1);

        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font2;
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setWeight(75);
        label->setFont(font2);

        gridLayout->addWidget(label, 2, 0, 1, 1);

        tableView = new QTableView(centralWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEnabled(true);
        tableView->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout->addWidget(tableView, 0, 0, 1, 3);

        comment = new QLineEdit(centralWidget);
        comment->setObjectName(QString::fromUtf8("comment"));
        comment->setEnabled(true);
        QFont font3;
        font3.setPointSize(12);
        comment->setFont(font3);
        comment->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));

        gridLayout->addWidget(comment, 1, 0, 1, 2);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        gridLayout->addWidget(label_2, 3, 0, 1, 1);

        Send = new QPushButton(centralWidget);
        Send->setObjectName(QString::fromUtf8("Send"));
        Send->setFont(font1);
        Send->setStyleSheet(QString::fromUtf8("color:rgb(0, 0, 0);"));

        gridLayout->addWidget(Send, 4, 0, 1, 2);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 832, 27));
        menuOptions = new QMenu(menuBar);
        menuOptions->setObjectName(QString::fromUtf8("menuOptions"));
        menuAbout = new QMenu(menuBar);
        menuAbout->setObjectName(QString::fromUtf8("menuAbout"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuOptions->menuAction());
        menuBar->addAction(menuAbout->menuAction());
        menuOptions->addAction(actionProductList);
        menuOptions->addAction(actionShoppingBasket);
        menuAbout->addAction(actionAbout_QT);
        menuAbout->addAction(actionAbout_Me);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Digikala", nullptr));
        actionProductList->setText(QApplication::translate("MainWindow", "Product List", nullptr));
        actionShoppingBasket->setText(QApplication::translate("MainWindow", "Shopping Basket", nullptr));
        actionAbout_QT->setText(QApplication::translate("MainWindow", "About QT", nullptr));
        actionAbout_Me->setText(QApplication::translate("MainWindow", "About Me", nullptr));
        checkBox->setText(QApplication::translate("MainWindow", "Do you recomend it?", nullptr));
        label->setText(QApplication::translate("MainWindow", "Advantages: ", nullptr));
        comment->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "Disadvantages:", nullptr));
        Send->setText(QApplication::translate("MainWindow", "Send Comment ", nullptr));
        menuOptions->setTitle(QApplication::translate("MainWindow", "Options", nullptr));
        menuAbout->setTitle(QApplication::translate("MainWindow", "About", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
