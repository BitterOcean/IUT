-- DATABASE DESIGN 1 3981 @ IUT
-- YOUR NAME:   Maryam Saeedmehr
-- YOUR STUDENT NUMBER:   9629373


---- Q4-a

create table City(
	CityID int not null primary key,
	Title varchar(20)
);

create table Branch(
	BranchID int not null primary key,
	Title varchar(20),
	CityID int,
	foreign key(CityID) references City(CityID)
);

create table Employee(
	PersonalCode bigint not null primary key,
	FirstName varchar(20),
	LastName varchar(20),
	CityID int,
	foreign key(CityID) references City(CityID)
);

create table BranchesEmployees(
	PersonalCode bigint,
	BranchID int,
	Salary int,
	primary key(PersonalCode,BranchID),
	foreign key(PersonalCode) references Employee(PersonalCode),
	foreign key(BranchID) references Branch(BranchID)
);

create table GroupManager(
	PersonalCode bigint,
	ManagerPersonalCode bigint,
	primary key(PersonalCode,ManagerPersonalCode),
	foreign key(PersonalCode) references Employee(PersonalCode),
	foreign key(ManagerPersonalCode) references Employee(PersonalCode)
);


---- Q4-b

with T as(
	select *
	from Employee inner join GroupManager using(PersonalCode))
select FirstName , LastName 
from T
where CityID = (select CityID from T where ManagerPersonalCode = PersonalCode)

---- Q4-c

select distinct CityID , count(PersonalCode) over (partition by CityID) , sum(Salary) over (partition by CityID)
from BranchesEmployees inner join Branch using(BranchID)
group by CityID, PersonalCode, Salary

---- Q4-d

select FirstName , LastName 
from BranchesEmployees inner join Employee using(PersonalCode) inner join Branch using(BranchID)
where title<>'Main Branch'

---- Q4-e

create view S as (
	select PersonalCode as S_code, FirstName , LastName ,Salary as S_Salary , title
	from BranchesEmployees inner join Employee using(PersonalCode) inner join Branch using(BranchID)
	where title <> 'Main Branch');
create view T as (
	select PersonalCode as T_code, Salary as T_Salary
	from BranchesEmployees inner join Employee using(PersonalCode) inner join Branch using(BranchID)
	where title = 'Main Branch');
select FirstName , LastName 
from S,T
where (S.S_code <> T.T_code and S.S_Salary > all(select T_Salary from T))

---- Q4-f

select FirstName , LastName , title
from S --S is a view defined in previous part
where S_code = (select ManagerPersonalCode 
		from S inner join GroupManager on (S.S_code = PersonalCode), T
		where S_Salary > all(select T_Salary from T))

---- Q4-g

update BranchesEmployees
set Salary = case 
		when Salary*1.05<=3000000 then Salary*1.05
		else Salary*1.02
		end
where PersonalCode = (select ManagerPersonalCode
		      from T inner join GroupManager on T.T_code = PersonalCode)

---- Q5-a

with W as (with T as (select distinct film_id , actor_id , first_name , last_name , store_id
				from film_actor inner join inventory using(film_id) inner join actor using(actor_id))
			select distinct store_id , first_name , last_name , count(*) over (partition by store_id , actor_id) as CNT
			from T )
select distinct store_id , first_name , last_name , max(CNT) over (partition by store_id)
from W
group by store_id , first_name , last_name , CNT
order by store_id asc

---- Q5-b

select distinct country , city , count(film_id) over(partition by country,city) as rental_num , sum(amount) over(partition by country,city) as tot_money
from payment	inner join rental using(rental_id) 
		inner join inventory using(inventory_id)
		inner join store using(store_id) 
		inner join address using(address_id)
		inner join city using(city_id)
		inner join country using(country_id)
group by rollup(country, city) , film_id , amount

---- Q5-c

with T as(select title , length , ntile(6) over(order by length) as length_group , replacement_cost
	  from film
	  order by length_group,rental_rate)
select title , length , length_group , sum(replacement_cost) over(partition by length_group rows unbounded preceding) as CumulativeSum_ReplacementCost
from T	

---- Q5-d

with T as(select country , rating , count(rating) 
    	  from rental 
				inner join inventory using(inventory_id)
				inner join film using(film_id)
				inner join customer using(customer_id)
				inner join address using(address_id)
				inner join city using(city_id)
				inner join country using(country_id)
		   group by country,rating)
select country , max(case when rating = 'G' then count end) as "G",
		  		  max(case when rating = 'PG' then count end) as "PG",
		  		  max(case when rating = 'PG-13' then count end) as "PG-13",
		  		  max(case when rating = 'R' then count end) as "R",
		  		  max(case when rating = 'NC-17' then count end) as "NC-17"
from T
group by country
order by country asc


