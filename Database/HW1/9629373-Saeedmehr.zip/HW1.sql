-- DATABASE DESIGN 1 3981 @ IUT
-- YOUR NAME:   Maryam Saeedmehr
-- YOUR STUDENT NUMBER:   9629373


---- Q10-a

select first_name, last_name, city
from (((customer inner join address using (address_id)) inner join city using (city_id)) inner join country using (country_id))
where country='Iran'


---- Q10-b

-- create view iranian(id_) as 
-- select customer_id
-- from (((customer inner join address using (address_id)) inner join city using (city_id)) inner join country using (country_id))
-- where country='Iran';

select distinct first_name, last_name
from (((rental inner join inventory using(inventory_id)) inner join film_actor using(film_id)) inner join actor using(actor_id)), iranian
where customer_id=id_


---- Q10-c

-- create or replace view iranian(id_, first_name, last_name) as 
-- select customer_id, first_name, last_name
-- from (((customer inner join address using (address_id)) inner join city using (city_id)) inner join country using (country_id))
-- where country='Iran';

select first_name, last_name, rental_date, return_date
from rental , iranian
where date(rental_date)=date(return_date)


---- Q10-d

-- create view Specialfilm(film_id) as 
-- select film_id
-- from
-- (
-- 	SELECT s.length, s.film_id ,
--          CASE WHEN s.rating = 'G' THEN 1 
--               WHEN s.rating = 'PG' THEN 2
--               WHEN s.rating = 'PG-13' THEN 3
--               WHEN s.rating = 'R' THEN 4
--               WHEN s.rating = 'NC-17' THEN 5
--               ELSE 6 END AS FilmRanking
-- 	FROM film as s
-- ) as r
-- where r.length>100 or r.FilmRanking>4;

select distinct first_name, last_name
from Specialfilm inner join film_actor using(film_id) inner join actor using(actor_id)


---- Q10-e

select distinct s.name
from (rental inner join inventory using(inventory_id) inner join film_category using(film_id) inner join category using(category_id)) as s
where s.store_id!=1 and s.store_id=2 and date(s.return_date) - date(s.rental_date) > 9


---- Q10-f

-- create or replace view v(title, len) as
-- select title , length(title)
-- from film
-- where title like '%s%s%' or title like '%g' or title like '%S%s%';

select film.title
from  film , v
group by(film.title)
having length(film.title) > max(v.len);


---- Q10-g

-- create view v as
-- select customer.customer_id , count(staff_id) as staff_2
-- from rental inner join customer using(customer_id) 
-- where staff_id=2
-- group by (customer.customer_id)

select customer.* , count(staff_id) as staff_1 , v.staff_2
from rental inner join customer using(customer_id) inner join v using(customer_id)
where staff_id=1 
group by (customer.customer_id, v.staff_2)
order by staff_1 ASC


---- Q10-h

create table category_rating as(with categoryAndFilmId as(select * from category INNER JOIN film_category ON 
(category.category_id = film_category.category_id)),
 validFilms as(select * from categoryAndFilmId INNER JOIN film ON 
(categoryAndFilmId.film_id = film.film_id))
select name,ROUND(AVG(rental_rate), 1),max(length) from validFilms group by name
)



---- Q10-i

-- alter table category_rating 
-- add age_rating int;
with categoryMaxRate as(with categoryAndFilmId as(select * from category INNER JOIN film_category ON 
(category.category_id = film_category.category_id)),
 validFilms as(select * from categoryAndFilmId INNER JOIN film ON 
(categoryAndFilmId.film_id = film.film_id)),
category_rate as(select rating,name from validFilms),

category_rate_count as(select name, rating,count(rating) from category_rate group by name,rating
),
T as (select name,max(category_rate_count.count) from category_rate_count group by name)
select T.name,rating from T,category_rate_count where T.max = category_rate_count.count and T.name=category_rate_count.name)

update category_rating 
set age_rating = (case 
				   when categoryMaxRate.rating = 'G' then 1
				  when categoryMaxRate.rating = 'PG' then 2
                  when categoryMaxRate.rating = 'PG-13' then 3
 				 ElSE 4
				  END
				 )
				 from categoryMaxRate where category_rating.name = categoryMaxRate.name



---- Q10-j

with categoryAndFilmId as(select * from category INNER JOIN film_category ON 
(category.category_id = film_category.category_id)),
 validFilms as(select * from categoryAndFilmId INNER JOIN film ON 
(categoryAndFilmId.film_id = film.film_id)),
TopCategory as (with T as (select * from category_rating order by round  desc)
select name from T limit 3),
avglength as (select name,ROUND(AVG(length), 1) from validFilms group by name),
avglengthtop_tbl as (select TopCategory.name,ROUND(AVG(length), 1) from validFilms,TopCategory where TopCategory.name = validFilms.name group by TopCategory.name),
avglengthtop as (select ROUND(AVG(avglengthtop_tbl.round), 1) from avglengthtop_tbl),
finalNames as(select name from avglength,avglengthtop where avglength.round >  avglengthtop.round
)
delete from category_rating where category_rating.name in (select name from finalNames)


